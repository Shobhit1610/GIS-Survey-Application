package oro.gis.service.impl;

import oro.gis.service.custom.EntryMakerModelCustomService;

public class EntryMakerModelServiceImpl implements EntryMakerModelCustomService
{

}
