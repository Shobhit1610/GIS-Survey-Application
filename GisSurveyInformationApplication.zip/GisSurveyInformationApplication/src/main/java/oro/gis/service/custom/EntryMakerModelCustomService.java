package oro.gis.service.custom;

public interface EntryMakerModelCustomService {

}
